RESTORE LOG database_name
FROM <backup_device>
WITH STOPAT = time, RECOVERY�