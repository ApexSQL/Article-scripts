SELECT
       *
  FROM sys.fn_dblog(NULL, NULL);