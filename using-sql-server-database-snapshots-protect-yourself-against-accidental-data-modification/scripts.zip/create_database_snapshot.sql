CREATE DATABASE AdventureWorks2012_SS14Sep2013 ON 
(NAME = [AdventureWorks2012_Data],
FILENAME = 'D:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\
MSSQL\DATA\AdventureWorks2012_Data_SS_14Sep2013.ss') 
AS SNAPSHOT OF AdventureWorks2012