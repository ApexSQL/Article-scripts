USE AdventureWorks2012
GO
SELECT * INTO Production.Illustration 
FROM AdventureWorks2012_Restored.Production.Illustration