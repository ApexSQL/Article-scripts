SELECT sys.fn_cdc_get_min_lsn('Person_Address') AS min_lsn
SELECT sys.fn_cdc_get_min_lsn() AS min_lsn