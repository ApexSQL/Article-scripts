cdc.fn_cdc_get_all_changes_capture_instance(from_lsn, to_lsn, 
'<row_filter_option>')