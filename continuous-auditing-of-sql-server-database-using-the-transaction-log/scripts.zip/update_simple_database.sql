UPDATE [dbo].[Table001]
SET [Name] = 'Changed_Name'
WHERE [id] > 102
GO