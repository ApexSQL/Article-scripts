UPDATE [Person].[AddressType] SET [Name] = N'Office #4'
WHERE [AddressTypeID] = 8