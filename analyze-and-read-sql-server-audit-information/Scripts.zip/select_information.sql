SELECT [AddressID]
	,[AddressLine1]
	,[City]
FROM [AdventureWorks].[Person].[Address