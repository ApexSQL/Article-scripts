INSERT INTO Person.AddressType ( AddressTypeID,
	                        NAME,
	                        rowguid,
	                        ModifiedDate
	)
VALUES (
	7
	,N'Office #2'
	,'7fb99e95-bdcf-4b13-982f-c3d8188cb5d0'
	,'20130509 00:00:00.000'
	);