USE AdventureWorks;
GO
GRANT CONTROL TO AuditConfiguration;