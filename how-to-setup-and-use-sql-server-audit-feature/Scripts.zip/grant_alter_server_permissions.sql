USE master;
GO
GRANT ALTER ANY SERVER AUDIT TO AuditConfigurationLogin