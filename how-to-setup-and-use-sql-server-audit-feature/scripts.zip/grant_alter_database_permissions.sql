USE AdventureWorks;
GO
GRANT ALTER ANY DATABASE AUDIT TO AuditConfigurationLogin