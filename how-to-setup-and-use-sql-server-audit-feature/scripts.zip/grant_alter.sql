USE AdventureWorks;
GO GRANT ALTER TO AuditConfiguration;