USE master;
GO
GRANT CONTROL SERVER TO AuditConfigurationLogin